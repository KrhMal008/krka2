# Group: ЭФБО-08-26
# Student: Кистанов Илья

# Задание 6. Вариант 9
# I0 = A, I1 = 1, I2 = ¬B, I3 = A ∧ ¬B
# Упрощённо: Y = ¬(S1 ∧ B) ∧ (A ∨ (S1 ⊕ S0))


def mux(a: int, b: int, s0: int, s1: int) -> int:
    # s1 != s0 — это исключающее ИЛИ (S1 ⊕ S0): 1, когда они разные
    return int(not (s1 and b) and (a or s1 != s0))


# Проверка: сравниваем с «настоящим» мультиплексором,
# который просто выбирает вход по номеру S1S0
def mux_by_table(a, b, s0, s1):
    i0 = a
    i1 = 1
    i2 = int(not b)
    i3 = int(a and not b)
    inputs = [i0, i1, i2, i3]
    number = s1 * 2 + s0
    return inputs[number]


print("A B S1 S0 | Y")
for a in [0, 1]:
    for b in [0, 1]:
        for s1 in [0, 1]:
            for s0 in [0, 1]:
                y = mux(a, b, s0, s1)
                print(a, b, s1, "", s0, " |", y)
                assert y == mux_by_table(a, b, s0, s1)

print("Проверка пройдена: упрощённая формула = мультиплексор")
