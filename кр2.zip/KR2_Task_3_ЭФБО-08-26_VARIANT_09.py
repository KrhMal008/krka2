# Group: ЭФБО-08-26
# Student: Кистанов Илья

# Задание 3. Вариант 9
# Было:  F = (A → B) ∧ (A ∨ ¬B)
# Стало: F = (A ∧ B) ∨ (¬A ∧ ¬B)


def f(a: bool, b: bool, c: bool) -> bool:
    # c не нужна: после упрощения она пропала
    return (a and b) or (not a and not b)


# Проверка: печатаем таблицу
print("A B C | F")
for a in [False, True]:
    for b in [False, True]:
        for c in [False, True]:
            print(int(a), int(b), int(c), "|", int(f(a, b, c)))
