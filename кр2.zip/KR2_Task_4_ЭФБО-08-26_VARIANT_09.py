# Group: ЭФБО-08-26
# Student: Кистанов Илья

# Задание 4. Вариант 9. УФ-дезинфекция
# UV_On = ¬Presence ∧ DoorClosed ∧ StartCmd


def uv_on(presence: int, door_closed: int, start_cmd: int) -> int:
    # Лампа горит, только если людей нет, дверь закрыта и есть команда
    return int(not presence and door_closed and start_cmd)


# Пример ввода-вывода
print("Пример ввода: 0 1 1")
print("Пример вывода:", uv_on(0, 1, 1))
print()

# Полная таблица истинности
print("Presence DoorClosed StartCmd | UV_On")
for presence in [0, 1]:
    for door_closed in [0, 1]:
        for start_cmd in [0, 1]:
            print("   ", presence, "       ", door_closed, "       ", start_cmd,
                  "    |  ", uv_on(presence, door_closed, start_cmd))
