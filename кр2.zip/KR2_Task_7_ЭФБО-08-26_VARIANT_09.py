# Group: ЭФБО-08-26
# Student: Кистанов Илья

# Задание 7. Вариант 9
# F = ¬(A ∧ (B ∨ C))


def f(a: int, b: int, c: int) -> int:
    return int(not (a and (b or c)))


# Таблица из условия варианта 9
given = {
    (0, 0, 0): 1,
    (0, 0, 1): 1,
    (0, 1, 0): 1,
    (0, 1, 1): 1,
    (1, 0, 0): 1,
    (1, 0, 1): 0,
    (1, 1, 0): 0,
    (1, 1, 1): 0,
}

print("A B C | F")
for (a, b, c), answer in given.items():
    print(a, b, c, "|", f(a, b, c))
    assert f(a, b, c) == answer

print("Проверка пройдена: формула совпадает с таблицей")
